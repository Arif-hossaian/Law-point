"use strict";
exports.id = 11;
exports.ids = [11];
exports.modules = {

/***/ 2011:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "z": () => (/* binding */ Button)
});

// UNUSED EXPORTS: IconButton

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: ./utils/assertions.tsx
const __DEV__ = "production" !== "production";

;// CONCATENATED MODULE: ./components/Button/index.tsx



const Button = /*#__PURE__*/ (0,external_react_.forwardRef)(({ children , variant ="solid" , size ="md" , fullWidth =false , className , as ="button" , isExternal =false , ...rest }, ref)=>{
    let tempClassNames = [];
    const sharedClasses = [
        "focus:outline-none",
        "focus:ring-2",
        "focus:ring-indigo-400",
        "focus:ring-offset-2",
        "focus:ring-offset-indigo-50",
        "font-semibold",
        "rounded-full",
        "inline-flex",
        "flex-shrink-0",
        "items-center",
        "justify-center",
        "hover:-translate-y-0.5",
        "transition-all",
        "ease-in-out",
        "duration-150", 
    ];
    if (fullWidth) sharedClasses.push("w-full");
    // handle variants
    let btnSolid = [
        "bg-indigo-600",
        "hover:bg-indigo-700",
        "text-white",
        "fill-white",
        "shadow-lg",
        "shadow-indigo-600/40", 
    ];
    let btnOutline = [
        "text-gray-600",
        "fill-gray-600",
        "dark:text-white",
        "hover:text-indigo-600",
        "hover:fill-indigo-600",
        "hover:dark:text-indigo-600",
        "bg-transparent",
        "hover:bg-indigo-50",
        "border",
        "border-indigo-600", 
    ];
    let btnGhost = [
        "bg-indigo-50",
        "text-indigo-600",
        "hover:bg-indigo-100",
        "hover:text-indigo-600",
        "hover:dark:text-indigo-600", 
    ];
    if (variant === "solid") {
        tempClassNames = [
            ...sharedClasses,
            ...btnSolid
        ];
    } else if (variant === "outline") {
        tempClassNames = [
            ...sharedClasses,
            ...btnOutline
        ];
    } else if (variant === "ghost") {
        tempClassNames = [
            ...sharedClasses,
            ...btnGhost
        ];
    }
    // handle sizes
    let sizeSm = [
        "h-8",
        "px-3",
        "text-sm"
    ];
    let sizeMd = [
        "h-10",
        "px-6"
    ];
    let sizeLg = [
        "h-12",
        "px-6",
        "text-lg"
    ];
    if (size === "sm") {
        tempClassNames = [
            ...tempClassNames,
            ...sizeSm
        ];
    } else if (size === "md") {
        tempClassNames = [
            ...tempClassNames,
            ...sizeMd
        ];
    } else if (size === "lg") {
        tempClassNames = [
            ...tempClassNames,
            ...sizeLg
        ];
    }
    let classes = tempClassNames.join(" ");
    let Element = as ? /*#__PURE__*/ external_react_default().createElement(as, {
        className: `${classes} ${className}`,
        target: isExternal ? "_blank" : undefined,
        rel: isExternal ? "noopener noreferrer" : undefined,
        ref,
        ...rest
    }, children) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
        ...rest,
        className: `${classes} ${className}`,
        ref: ref,
        children: children
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: `relative ${fullWidth ? "w-full" : undefined}`,
        children: Element
    });
});
if (__DEV__) {
    Button.displayName = "Button";
}
const IconButton = /*#__PURE__*/ (0,external_react_.forwardRef)(({ children , icon , className , "aria-label": ariaLabel , size ="md" , ...rest }, ref)=>{
    let sharedClasses = [
        "rounded-full",
        "!px-0"
    ];
    // handle sizes
    let sizeSm = [
        "w-8"
    ];
    let sizeMd = [
        "w-10"
    ];
    let sizeLg = [
        "w-12"
    ];
    if (size === "sm") {
        sharedClasses = [
            ...sharedClasses,
            ...sizeSm
        ];
    } else if (size === "md") {
        sharedClasses = [
            ...sharedClasses,
            ...sizeMd
        ];
    } else if (size === "lg") {
        sharedClasses = [
            ...sharedClasses,
            ...sizeLg
        ];
    }
    /**
     * Passing the icon as prop or children should work
     */ const element = icon || children;
    const _children = /*#__PURE__*/ external_react_default().isValidElement(element) ? /*#__PURE__*/ external_react_default().cloneElement(element, {
        "aria-hidden": true,
        focusable: false
    }) : null;
    let classes = sharedClasses.join(" ");
    return /*#__PURE__*/ jsx_runtime_.jsx(Button, {
        className: `${classes} ${className}`,
        "aria-label": ariaLabel,
        size: size,
        ...rest,
        ref: ref,
        children: _children
    });
});
if (__DEV__) {
    IconButton.displayName = "IconButton";
}


/***/ })

};
;